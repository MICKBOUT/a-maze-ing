#!/usr/bin/env python3
"""Maze solving algorithm (BFS)."""

from .config import Config
from collections import deque
from .utils.mlx_utils import XVar, Bit_position


def resolve(pos: tuple[int, int], direction: int,
            maze: list[list[int]],
            visited: list[list[bool]] | None,
            config: Config, xvar: XVar) -> list[str] | bool:
    """
    Solve the maze using Breadth-First Search (BFS).

    Args:
        pos (tuple[int, int]): The starting position (x, y).
        direction (int): Initial direction (unused in BFS implementation).
        maze (list[list[int]]): The maze grid.
        visited (list[list[bool]] | None): Matrix of visited cells.
        config (Config): Configuration object containing exit coordinates.
        xvar (XVar): XVar object for rendering (unused in logic).

    Returns:
        list[str] | bool: A list of directions ('N', 'S', 'E', 'W') \
representing the path,
                          or False if no solution is found.
    """
    queue = deque([pos])
    visited_set = {pos}
    came_from: dict[tuple[int, int], tuple[int, int] | None] = {pos: None}
    end_pos = tuple(config.EXIT)

    final_node: tuple[int, int] | None = None

    while queue:
        current = queue.popleft()

        if current == end_pos:
            final_node = current
            break

        x, y = current
        movements = [
            (0, -1, Bit_position.NORTH.value),
            (1, 0, Bit_position.EAST.value),
            (0, 1, Bit_position.SOUTH.value),
            (-1, 0, Bit_position.WEST.value)
        ]

        for dx, dy, direction_bit in movements:
            if not (maze[y][x] & direction_bit):
                continue

            nx, ny = x + dx, y + dy

            if not (0 <= nx < config.WIDTH and 0 <= ny < config.HEIGHT):
                continue

            if (nx, ny) not in visited_set:
                visited_set.add((nx, ny))
                came_from[(nx, ny)] = current
                queue.append((nx, ny))

    if final_node:
        path = []
        curr = final_node
        while curr != pos:
            parent = came_from[curr]
            if parent is None:
                break
            dx, dy = curr[0] - parent[0], curr[1] - parent[1]

            d = ""
            if dx == 0 and dy == -1:
                d = "N"
            elif dx == 1 and dy == 0:
                d = "E"
            elif dx == 0 and dy == 1:
                d = "S"
            elif dx == -1 and dy == 0:
                d = "W"
            path.append(d)

            if curr != end_pos:
                xvar.path.append((curr[0], curr[1]))
            curr = parent
        path.reverse()
        return path
    return False
